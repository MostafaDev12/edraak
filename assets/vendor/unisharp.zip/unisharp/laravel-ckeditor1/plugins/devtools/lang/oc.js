﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","oc",{title:"Informacions sus l'element",dialogName:"Nom de la bóstia de dialòg",tabName:"Nom de l'onglet",elementId:"ID de l'element",elementType:"Element tipe"});