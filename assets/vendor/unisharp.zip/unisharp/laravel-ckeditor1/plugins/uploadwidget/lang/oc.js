﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","oc",{abort:"Mandadís interromput per l'utilizaire",doneOne:"Fichièr mandat amb succès.",doneMany:"%1 fichièrs mandats amb succès.",uploadOne:"Mandadís del fichièr en cors ({percentage} %)…",uploadMany:"Mandadís dels fichièrs en cors, {current} sus {max} efectuats ({percentage} %)…"});