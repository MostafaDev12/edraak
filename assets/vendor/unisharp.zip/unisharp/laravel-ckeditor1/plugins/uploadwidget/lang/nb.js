﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","nb",{abort:"Opplasting ble avbrutt av brukeren.",doneOne:"Filen har blitt lastet opp.",doneMany:"Fullført opplasting av %1 filer.",uploadOne:"Laster opp fil ({percentage}%)...",uploadMany:"Laster opp filer, {current} av {max} fullført ({percentage}%)..."});